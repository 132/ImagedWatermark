Embedding/ Hiding Image Within Image (with N-bit LSB steganography)
-------------------------------------------------------------------
The objective is to illustrate how certain reference may be made to a given image.
Executing reference usage: usage_

Uses Gray-scaled image (as target image) and embedd / hide a low resolution image within using N-bit LSB steganography.

* Caveat:
- HTML / other forms of documents may be generated. This is only a simple sample.
- For educational reference only.

Ref:
http://www.mathworks.com/matlabcentral/fileexchange/36275-image-description-notes-with-n-bit-lsb-steganography

If the reference demo has a more elegant presentation, please do not hesitate to suggest and send feedback to author.
Email: promethevx@yahoo.com.

Thank you.

Regards,
Michael Chan JT

-------------------------------------- EOF --------------------------------------