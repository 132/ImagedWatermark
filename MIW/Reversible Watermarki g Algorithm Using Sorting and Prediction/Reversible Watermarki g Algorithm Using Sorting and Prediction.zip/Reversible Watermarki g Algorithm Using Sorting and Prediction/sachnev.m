function TpTnpsnrmap = sachnev(originalImage,bpp)
originalImage = double(originalImage);
maxT=150;
TpTnpsnrmap=ones(length(bpp),5)*NaN;
TpTnpsnrmap(:,1)=bpp;
T=1; kb=0;
while kb<length(bpp) && T<maxT
    kb=kb+1;
    disp(['sachnev        ',num2str(bpp(kb),'%1.2f'),' ','bpp'])
    watermark=randint(1,round(bpp(kb)*numel(originalImage)/2),[0 1]);
    [cross_c,cross_r,cross_uh,cross_u] = crossset(originalImage);
    check=0;
    T=1;
    while T<=maxT && check==0
        [embeded_cross_image,PLcheckcross,last_bit_cross,LC_cross]=embeded(cross_c,cross_r,cross_uh,cross_u,watermark,T,originalImage);
        if PLcheckcross==1
           [dot_c,dot_r,dot_uh,dot_u] = dotset(embeded_cross_image); 
           [embeded_dot_image,PLcheckdot,last_bit_dot,LC_dot]=embeded(dot_c,dot_r,dot_uh,dot_u,watermark,T,embeded_cross_image); 
           if PLcheckdot==1
              check=1;
              MSE_o=inf;
              MSE_n=sum(sum((embeded_dot_image-originalImage).^2))/(numel(originalImage));
              image_n=embeded_dot_image;
              LC_n=LC_cross+LC_dot;
              while MSE_n<MSE_o
                    T=T+1;
                    [embeded_cross_image,PLcheckcross,last_bit_cross,LC_cross]=embeded(cross_c,cross_r,cross_uh,cross_u,watermark,T,originalImage);
                    [dot_c,dot_r,dot_uh,dot_u] = dotset(embeded_cross_image); 
                    [embeded_dot_image,PLcheckdot,last_bit_dot,LC_dot]=embeded(dot_c,dot_r,dot_uh,dot_u,watermark,T,embeded_cross_image); 
                    MSE_o=MSE_n;
                    MSE_n=sum(sum((embeded_dot_image-originalImage).^2))/(numel(originalImage));
                    image_o=image_n;   image_n=embeded_dot_image;
                    LC_o=LC_n;  LC_n=LC_cross+LC_dot;
              end  
              embeded_dot_image=image_o;
            end
        end
        T=T+1;
    end
    if check==1
        Mean2err=sum(sum((embeded_dot_image-originalImage).^2))/(numel(originalImage));
        sdf=255^2./(Mean2err);
        PSNR = 10*log10(sdf); 
        TpTnpsnrmap(kb,2)= PSNR;
        TpTnpsnrmap(kb,3)=-floor((T-2)/2);
        TpTnpsnrmap(kb,4)=ceil((T-2)/2)-1;
        TpTnpsnrmap(kb,5)=LC_o;
    end
end
